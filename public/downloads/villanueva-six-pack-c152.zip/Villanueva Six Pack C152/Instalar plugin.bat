@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-plugin.ps1"
