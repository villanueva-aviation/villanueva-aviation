﻿# Instala el plugin Villanueva Motor en SimHub: el .dll en la carpeta de SimHub y el lector en la de MSFS.
param([string]$SimHub)
$ErrorActionPreference = 'Stop'
$aqui = $PSScriptRoot

function Termina($mensaje) {
    Write-Host ""
    Write-Host $mensaje
    Read-Host "Presiona Enter para cerrar" | Out-Null
    exit
}

try {
    if (-not $SimHub) { $SimHub = (Get-ItemProperty HKCU:\Software\SimHub -ErrorAction SilentlyContinue).InstallDirectory }
    if (-not $SimHub) { $SimHub = Join-Path ${env:ProgramFiles(x86)} "SimHub" }
    if (-not (Test-Path (Join-Path $SimHub "SimHubWPF.exe"))) {
        Termina "No encontré SimHub en '$SimHub'. Instala SimHub y vuelve a ejecutar el instalador."
    }
    if (Get-Process SimHubWPF -ErrorAction SilentlyContinue) {
        Termina "SimHub está abierto. Ciérralo (también desde el ícono junto al reloj) y vuelve a ejecutar el instalador."
    }
    $msfs = Join-Path $SimHub "_Addons\GamePlugins\FlightSimulator"
    if (-not (Test-Path $msfs)) {
        Termina "Falta la carpeta de MSFS en SimHub. Abre SimHub una vez, elige Microsoft Flight Simulator como juego, ciérralo y vuelve a intentar."
    }

    $destinos = @{ (Join-Path $SimHub "VillanuevaMotorPlugin.dll") = "VillanuevaMotorPlugin.dll"; (Join-Path $msfs "VillanuevaMotorReader.exe") = "VillanuevaMotorReader.exe" }
    try {
        foreach ($d in $destinos.Keys) { Copy-Item (Join-Path $aqui "plugin\$($destinos[$d])") $d -Force }
    } catch [System.UnauthorizedAccessException] {
        # La carpeta de SimHub esta en Archivos de programa: repite con permisos de administrador.
        Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -SimHub `"$SimHub`""
        exit
    }
    # Windows marca lo descargado de internet y SimHub no carga un .dll marcado.
    foreach ($d in $destinos.Keys) { Unblock-File $d }
    Termina "Listo. Abre SimHub, acepta el plugin 'Villanueva Motor' y luego haz doble clic en 'Villanueva Six Pack.simhubdash'."
} catch {
    Termina "No se pudo instalar: $($_.Exception.Message)"
}
